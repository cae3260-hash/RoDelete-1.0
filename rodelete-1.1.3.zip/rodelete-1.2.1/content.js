
(() => {
  "use strict";

  const STYLE_ID = "rodelete-cosmic-style";
  const BAR_ID = "rodelete-control-bar";
  const DELETE_CLASS = "rodelete-delete-button";
  const CHECK_CLASS = "rodelete-select-checkbox";

  const selectedIds = new Set();
  const deletingIds = new Set();

  let groupMode = false;
  let bulkDeleting = false;
  let observer = null;
  let scanQueued = false;

  function isFriendsPage() {
    return /^\/users\/friends\/?$/i.test(location.pathname);
  }

  function getUserId(link) {
    if (!link) return null;

    const match = (link.getAttribute("href") || "").match(
      /\/users\/(\d+)\/profile(?:[/?#]|$)/i
    );

    return match ? match[1] : null;
  }

  function getFriendLinks() {
    if (!isFriendsPage()) return [];

    return Array.from(
      document.querySelectorAll('main a[href*="/users/"]')
    ).filter(link => {
      if (!getUserId(link)) return false;
      if (!link.querySelector("img")) return false;
      if (link.closest(`#${BAR_ID}`)) return false;
      if (link.closest("header, nav, footer")) return false;
      return true;
    });
  }

  function getAvatarHost(link) {
    const avatar = link.querySelector("img");
    if (!avatar) return null;

    const avatarLink = avatar.closest("a");
    const host = avatarLink || avatar.parentElement;

    return host && host.isConnected ? host : null;
  }

  function getFriendCard(link) {
    return (
      link.closest("li") ||
      link.parentElement?.parentElement ||
      link.parentElement ||
      link
    );
  }

  function addStyles() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;

    style.textContent = `
      @keyframes rd-pulse {
        0%, 100% { box-shadow: 0 0 6px #ff287955; }
        50% { box-shadow: 0 0 13px #ff2879aa; }
      }

      .${DELETE_CLASS} {
        position: absolute !important;
        top: 2px !important;
        right: 2px !important;
        left: auto !important;
        bottom: auto !important;
        z-index: 99999 !important;
        width: 25px !important;
        height: 25px !important;
        min-width: 25px !important;
        min-height: 25px !important;
        padding: 0 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-sizing: border-box !important;
        border: 1px solid #ff9bc8 !important;
        border-radius: 8px !important;
        background: linear-gradient(145deg, #a20f49, #f12667) !important;
        color: white !important;
        font: bold 20px/1 Arial, sans-serif !important;
        cursor: pointer !important;
        animation: rd-pulse 2s infinite;
      }

      .${DELETE_CLASS}:hover {
        transform: scale(1.1);
        box-shadow: 0 0 16px #ff2879 !important;
      }

      .${DELETE_CLASS}:disabled {
        opacity: .6 !important;
        cursor: wait !important;
      }

      #${BAR_ID} {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 9px;
        margin: 14px 0;
        padding: 14px;
        border: 1px solid #536dca;
        border-radius: 14px;
        color: #e9f4ff;
        background:
          radial-gradient(ellipse at top left, #263b78, transparent 65%),
          linear-gradient(135deg, #090e25, #17112f 60%, #091d35);
        box-shadow: 0 0 18px #3979ff22;
        font: 13px system-ui, sans-serif;
      }

      #${BAR_ID} .rd-title {
        width: 100%;
        color: #80e9ff;
        font-weight: 800;
        letter-spacing: 2px;
      }

      #${BAR_ID} button {
        padding: 9px 12px;
        border: 1px solid #6388ff;
        border-radius: 9px;
        color: white;
        background: linear-gradient(135deg, #3549a0, #6535a8);
        font: 600 12px system-ui, sans-serif;
        cursor: pointer;
      }

      #${BAR_ID} button:disabled {
        opacity: .5;
        cursor: not-allowed;
      }

      #${BAR_ID} .rd-count {
        color: #82edff;
        font-weight: 700;
      }

      .${CHECK_CLASS} {
        position: absolute !important;
        top: 5px !important;
        left: 5px !important;
        right: auto !important;
        bottom: auto !important;
        z-index: 99998 !important;
        width: 20px !important;
        height: 20px !important;
        margin: 0 !important;
        accent-color: #8c6bff !important;
        cursor: pointer !important;
      }

      .rd-cosmic-selected {
        outline: 2px solid #8c6bff !important;
        outline-offset: -2px !important;
      }

      html.rd-group-mode .${DELETE_CLASS} {
        display: none !important;
      }
    `;

    document.head.appendChild(style);
  }

  function getBar() {
    return document.getElementById(BAR_ID);
  }

  function updateCount() {
    const bar = getBar();
    if (!bar) return;

    const count = bar.querySelector(".rd-count");
    const removeButton = bar.querySelector(".rd-remove");

    if (count) {
      count.textContent = `✦ ВЫБРАНО: ${selectedIds.size}`;
    }

    if (removeButton) {
      removeButton.disabled =
        selectedIds.size === 0 || bulkDeleting;
    }
  }

  async function unfriend(userId) {
    const url =
      `https://friends.roblox.com/v1/users/${userId}/unfriend`;

    let response = await fetch(url, {
      method: "POST",
      credentials: "include"
    });

    if (response.status === 403) {
      const token = response.headers.get("x-csrf-token");

      if (!token) {
        throw new Error(
          "Roblox отклонил запрос. Обнови страницу и попробуй снова."
        );
      }

      response = await fetch(url, {
        method: "POST",
        credentials: "include",
        headers: {
          "X-CSRF-TOKEN": token
        }
      });
    }

    if (!response.ok) {
      throw new Error(`Запрос Roblox завершился с кодом ${response.status}`);
    }
  }

  function removeCardFromPage(userId) {
    const link = getFriendLinks().find(
      item => getUserId(item) === userId
    );

    if (!link) return;

    const card = getFriendCard(link);
    if (card && card !== document.body && card !== document.documentElement) {
      card.remove();
    }
  }

  async function removeFriend(userId, button = null) {
    if (deletingIds.has(userId)) return;

    deletingIds.add(userId);

    if (button) {
      button.disabled = true;
      button.textContent = "…";
    }

    try {
      await unfriend(userId);

      selectedIds.delete(userId);
      removeCardFromPage(userId);
      updateCount();
    } catch (error) {
      console.error("[RoDelete] Не удалось удалить друга:", error);

      if (button) {
        button.disabled = false;
        button.textContent = "×";
      }

      alert(
        `Не удалось удалить друга.\n${error.message || "Неизвестная ошибка"}`
      );
    } finally {
      deletingIds.delete(userId);
      updateCount();
    }
  }

  function addDeleteButton(link, userId) {
    const host = getAvatarHost(link);
    if (!host) return;

    const exists = Array.from(
      host.querySelectorAll(`.${DELETE_CLASS}`)
    ).some(button => button.dataset.userId === userId);

    if (exists) return;

    if (getComputedStyle(host).position === "static") {
      host.style.position = "relative";
    }

    const button = document.createElement("button");
    button.type = "button";
    button.className = DELETE_CLASS;
    button.dataset.userId = userId;
    button.textContent = "×";
    button.title = "Удалить из друзей";
    button.setAttribute("aria-label", "Удалить из друзей");

    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();

      removeFriend(userId, button);
    });

    host.appendChild(button);
  }

  function addCheckbox(link, userId) {
    if (!groupMode) return;

    const host = getFriendCard(link);
    if (!host) return;

    const exists = Array.from(
      host.querySelectorAll(`.${CHECK_CLASS}`)
    ).some(box => box.dataset.userId === userId);

    if (exists) return;

    if (getComputedStyle(host).position === "static") {
      host.style.position = "relative";
    }

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = CHECK_CLASS;
    checkbox.dataset.userId = userId;
    checkbox.title = "Выбрать друга";
    checkbox.checked = selectedIds.has(userId);

    checkbox.addEventListener("click", event => {
      event.stopPropagation();
    });

    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        selectedIds.add(userId);
        host.classList.add("rd-cosmic-selected");
      } else {
        selectedIds.delete(userId);
        host.classList.remove("rd-cosmic-selected");
      }

      updateCount();
    });

    host.appendChild(checkbox);
  }

  function removeAllCheckboxes() {
    document.querySelectorAll(`.${CHECK_CLASS}`).forEach(box => {
      box.remove();
    });

    document.querySelectorAll(".rd-cosmic-selected").forEach(card => {
      card.classList.remove("rd-cosmic-selected");
    });
  }

  function createBar() {
    if (getBar()) return;

    const main = document.querySelector("main");
    if (!main) return;

    const bar = document.createElement("section");
    bar.id = BAR_ID;

    const title = document.createElement("div");
    title.className = "rd-title";
    title.textContent = "✦ RODELETE / COSMIC CONTROL";

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "rd-toggle";
    toggle.textContent = "◈ Групповой режим: ВЫКЛ";

    const selectAll = document.createElement("button");
    selectAll.type = "button";
    selectAll.textContent = "Выбрать всех";

    const clear = document.createElement("button");
    clear.type = "button";
    clear.textContent = "Снять выбор";

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "rd-remove";
    remove.textContent = "Удалить выбранных";
    remove.disabled = true;

    const count = document.createElement("span");
    count.className = "rd-count";
    count.textContent = "✦ ВЫБРАНО: 0";

    bar.append(title, toggle, selectAll, clear, remove, count);
    main.prepend(bar);

    toggle.addEventListener("click", () => {
      groupMode = !groupMode;

      document.documentElement.classList.toggle(
        "rd-group-mode",
        groupMode
      );

      toggle.textContent =
        `◈ Групповой режим: ${groupMode ? "ВКЛ" : "ВЫКЛ"}`;

      if (!groupMode) {
        removeAllCheckboxes();
      }

      scan();
    });

    selectAll.addEventListener("click", () => {
      if (!groupMode) return;

      getFriendLinks().forEach(link => {
        const userId = getUserId(link);
        if (!userId) return;

        selectedIds.add(userId);

        const card = getFriendCard(link);
        card.classList.add("rd-cosmic-selected");

        card.querySelectorAll(`.${CHECK_CLASS}`).forEach(box => {
          if (box.dataset.userId === userId) {
            box.checked = true;
          }
        });
      });

      updateCount();
    });

    clear.addEventListener("click", () => {
      selectedIds.clear();

      document.querySelectorAll(`.${CHECK_CLASS}`).forEach(box => {
        box.checked = false;
      });

      document.querySelectorAll(".rd-cosmic-selected").forEach(card => {
        card.classList.remove("rd-cosmic-selected");
      });

      updateCount();
    });

    remove.addEventListener("click", async () => {
      if (bulkDeleting || selectedIds.size === 0) return;

      const ids = Array.from(selectedIds);

      bulkDeleting = true;
      updateCount();

      try {
        for (const userId of ids) {
          await removeFriend(userId);
        }
      } finally {
        bulkDeleting = false;
        updateCount();
      }
    });
  }

  function scan() {
    if (!document.body || !isFriendsPage()) return;

    addStyles();
    createBar();

    for (const link of getFriendLinks()) {
      const userId = getUserId(link);
      if (!userId) continue;

      if (groupMode) {
        addCheckbox(link, userId);
      } else {
        addDeleteButton(link, userId);
      }
    }

    updateCount();
  }

  function scheduleScan() {
    if (scanQueued) return;

    scanQueued = true;

    requestAnimationFrame(() => {
      scanQueued = false;
      scan();
    });
  }

  function start() {
    if (!document.body) return;

    scan();

    if (observer) observer.disconnect();

    observer = new MutationObserver(scheduleScan);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
