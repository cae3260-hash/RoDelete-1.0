# RoDelete 1.2.1

Fix: the extension now filters out the signed-in user's own profile link so it won't place a red × or group-selection checkbox on your own profile.

- Click **Group** to select friends.
- Select friends manually or use **Выбрать всех**.
- Click **Удалить выбранных** to remove selected friends.
- Single-friend red × remains available on friend cards.

Update: remove the previous version from `chrome://extensions`, extract this ZIP, click **Load unpacked**, select `rodelete-1.2.1`, and reload Roblox.
