# RoDelete 1.1.2

Clicking the red × starts friend removal immediately without a confirmation dialog.

Update: open chrome://extensions, remove the previous RoDelete version, extract this ZIP, click Load unpacked, and choose the `rodelete-1.1.2` folder. Then reload your Roblox friends page.

Because removal is immediate, take care to click the intended friend's button.
