(() => {
  "use strict";

  const BUTTON_CLASS = "rfc-remove-friend";
  const STYLE_ID = "rfc-styles";
  const FRIENDS_PATH = /\/users\/friends/i;
  const pending = new Set();

  function isFriendsPage() {
    return FRIENDS_PATH.test(location.pathname);
  }

  function addStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .${BUTTON_CLASS} {
        display:inline-flex!important;align-items:center!important;justify-content:center!important;
        width:22px!important;height:22px!important;min-width:22px!important;
        margin:0!important;padding:0!important;border:0!important;border-radius:5px!important;
        background:#e53935!important;color:#fff!important;font:bold 16px/1 Arial,sans-serif!important;
        cursor:pointer!important;position:absolute!important;z-index:99999!important;
        box-shadow:0 1px 4px #0004!important;
      }
      .${BUTTON_CLASS}:hover {background:#b71c1c!important}
      .${BUTTON_CLASS}:disabled {opacity:.55!important;cursor:wait!important}
    `;
    document.head.appendChild(style);
  }

  function userIdFromLink(a) {
    return a.href.match(/\/users\/(\d+)\/profile/i)?.[1] || null;
  }

  function profileLinks() {
    return [...document.querySelectorAll('a[href*="/users/"][href*="/profile"]')]
      .filter(a => userIdFromLink(a) && !a.closest("nav") && !a.closest("header"));
  }

  function findCard(link) {
    let node = link;
    for (let depth = 0; depth < 12 && node && node !== document.body; depth++, node = node.parentElement) {
      const ids = [...node.querySelectorAll('a[href*="/users/"][href*="/profile"]')]
        .map(userIdFromLink).filter(Boolean);
      const hasAvatar = !!node.querySelector("img,[role='img']");
      const text = (node.innerText || "").trim();
      if (ids.length === 1 && hasAvatar && text.length > 0 && text.length < 900) return node;
    }
    return link.parentElement;
  }

  async function unfriend(userId) {
    const url = `https://friends.roblox.com/v1/users/${encodeURIComponent(userId)}/unfriend`;
    // Roblox uses CSRF protection. The first request may return a token in its
    // response headers; retry the same authenticated action with that token.
    let response = await fetch(url, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: "{}"
    });

    if (response.status === 403) {
      const token = response.headers.get("x-csrf-token");
      if (token) {
        response = await fetch(url, {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": token
          },
          body: "{}"
        });
      }
    }

    if (!response.ok) {
      let detail = "";
      try {
        const data = await response.json();
        detail = data?.errors?.map(e => e.message).filter(Boolean).join("; ") || "";
      } catch (_) {}
      throw new Error(detail || `Roblox вернул статус ${response.status}`);
    }
  }

  function addButton(link) {
    const userId = userIdFromLink(link);
    if (!userId) return;
    const card = findCard(link);
    if (!card || [...card.querySelectorAll(`.${BUTTON_CLASS}`)].some(b => b.dataset.userId === userId)) return;

    const avatar = card.querySelector("img,[role='img']");
    if (!avatar) return;

    const anchor = avatar.closest("a") || avatar;
    const host = anchor.parentElement || card;
    if (getComputedStyle(host).position === "static") host.style.position = "relative";

    const button = document.createElement("button");
    button.type = "button";
    button.className = BUTTON_CLASS;
    button.textContent = "×";
    button.title = "Удалить из друзей";
    button.setAttribute("aria-label", "Удалить из друзей");
    button.dataset.userId = userId;
    button.style.left = "4px";
    button.style.bottom = "-4px";
    host.appendChild(button);

    button.addEventListener("click", async event => {
      event.preventDefault();
      event.stopPropagation();
      if (pending.has(userId)) return;

      // No confirmation dialog: clicking the red × starts the removal immediately.
      pending.add(userId);
      button.disabled = true;
      button.textContent = "…";
      try {
        await unfriend(userId);
        // Remove all duplicate cards for this user, if present.
        document.querySelectorAll(`.${BUTTON_CLASS}[data-user-id="${CSS.escape(userId)}"]`)
          .forEach(b => {
            const cardNode = b.closest("li,[class*=" + CSS.escape("friend") + "]") || b.parentElement?.parentElement;
            if (cardNode && cardNode !== document.body) cardNode.remove();
            else b.remove();
          });
        if (card.isConnected) card.remove();
      } catch (error) {
        console.error("[Roblox Friend Cleaner]", error);
        button.disabled = false;
        button.textContent = "×";
        alert(`Не удалось удалить друга: ${error.message}\nПроверь, что ты вошёл в Roblox, и попробуй ещё раз.`);
      } finally {
        pending.delete(userId);
      }
    });
  }

  function scan() {
    if (!isFriendsPage()) return;
    addStyles();
    profileLinks().forEach(addButton);
  }

  let queued = false;
  const observer = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    setTimeout(() => { queued = false; scan(); }, 200);
  });

  scan();
  observer.observe(document.documentElement, { childList: true, subtree: true });

  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      scan();
    }
  }, 600);
})();